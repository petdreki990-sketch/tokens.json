# OSCARDEOB Termux

Telegram bot untuk analisis dan deobfuscation JavaScript secara **static-only**. Source upload tidak dieksekusi.

## Instalasi di Android / Termux

1. Install Termux dari sumber tepercaya (disarankan F-Droid).
2. Jalankan:

```bash
pkg update -y && pkg upgrade -y
pkg install nodejs-lts git unzip -y
```

3. Ekstrak ZIP project, masuk ke folder:

```bash
cd oscardeob-termux
npm install
cp .env.example .env
nano .env
```

4. Buat bot melalui Telegram **@BotFather** dengan `/newbot`.
5. Tempel token ke `.env`:

```env
BOT_TOKEN=123456:TOKEN_DARI_BOTFATHER
MAX_FILE_MB=15
```

Jangan bagikan token kepada siapa pun. Jangan upload `.env` ke GitHub.

6. Jalankan:

```bash
npm start
```

Buka bot Telegram, tekan Start, lalu kirim file JavaScript sebagai **Document**.

## Menjalankan kembali

```bash
cd oscardeob-termux
npm start
```

Untuk menghentikan: `Ctrl+C`.

## Yang dikerjakan engine

- P1: Parse dan beautify menggunakan Babel.
- P1.5: Decode pemanggilan `atob("...")` dengan argumen string literal.
- P2: Inline lookup indeks statis pada array string lokal yang immutable.
- P3: Pemeriksaan payload statis; tidak menjalankan kode.
- P4: Constant folding untuk operasi literal yang aman.
- P5: Normalisasi AST.
- P6: Rename lokal yang polanya menyerupai `_0x...`.
- P7: Generate hasil akhir.

## Batasan penting

Tidak ada deobfuscator universal yang dapat menjamin hasil sempurna. Engine ini sengaja konservatif: tidak menggunakan `eval`, `vm`, `Function`, `require` dari source upload, atau menjalankan file. Decoder RC4/custom, string array yang dirotasi saat runtime, control-flow flattening kompleks, anti-debug, dan payload yang memerlukan browser/server mungkin perlu analisis khusus.

Gunakan hanya pada kode yang kamu miliki atau berhak analisis. Periksa hasil sebelum menjalankannya.
