'use strict';

require('dotenv').config?.();
const { Bot, InputFile } = require('grammy');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { runDeobfuscation } = require('./deobfuscator');

const TOKEN = process.env.BOT_TOKEN;
const MAX_MB = Number(process.env.MAX_FILE_MB || 15);
if (!TOKEN || TOKEN === 'ISI_TOKEN_BOT_KAMU') {
  console.error('BOT_TOKEN belum diatur. Salin .env.example menjadi .env lalu isi token BotFather.');
  process.exit(1);
}

const bot = new Bot(TOKEN);
const active = new Set();
const fmt = n => (n / 1024 / 1024).toFixed(2) + ' MB';
const duration = ms => {
  const sec = Math.max(0, Math.round(ms / 1000));
  return `${Math.floor(sec / 60)} menit ${sec % 60} detik`;
};

bot.command('start', async ctx => {
  await ctx.reply(
    '🧩 OSCARDEOB — JavaScript Static Deobfuscator\n\n' +
    'Kirim file .js sebagai dokumen untuk dianalisis.\n' +
    'Perintah:\n/help — bantuan\n/about — informasi engine\n\n' +
    'Mode static-only: file tidak dieksekusi.'
  );
});
bot.command('help', async ctx => ctx.reply(
  'Cara pakai:\n1. Kirim file .js sebagai Document.\n2. Tunggu analisis P1–P7.\n3. Bot mengirim file hasil dan laporan.\n\n' +
  `Batas ukuran: ${MAX_MB} MB.\nJenis: JavaScript/JSX/TypeScript yang didukung parser Babel.\n` +
  'Catatan: hasil deobfuscation best-effort, bukan jaminan mengembalikan source asli.'
));
bot.command('about', async ctx => ctx.reply(
  'OSCARDEOB Termux 1.0\nEngine: Babel AST + static transforms\nDecoder: Base64 atob literal, immutable string-array lookup, literal folding\nSafety: uploaded source is NEVER executed.'
));

bot.on('message:document', async ctx => {
  const doc = ctx.message.document;
  const fileName = doc.file_name || 'upload.js';
  if (!/\.(js|mjs|cjs|jsx|ts)$/i.test(fileName)) {
    return ctx.reply('⚠️ Format tidak didukung. Kirim file .js, .mjs, .cjs, .jsx, atau .ts.');
  }
  if (doc.file_size && doc.file_size > MAX_MB * 1024 * 1024) {
    return ctx.reply(`⚠️ File terlalu besar. Batas konfigurasi bot: ${MAX_MB} MB.`);
  }
  if (active.has(ctx.from.id)) return ctx.reply('⏳ Permintaan sebelumnya masih diproses. Tunggu sebentar.');
  active.add(ctx.from.id);

  const job = crypto.randomBytes(6).toString('hex');
  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'oscardeob-'));
  const safeName = path.basename(fileName).replace(/[^\w.-]/g, '_');
  const inputPath = path.join(tempDir, safeName);
  const outputPath = path.join(tempDir, 'index.deobf.js');
  const reportPath = path.join(tempDir, 'oscardeob-report.txt');
  let statusMsg;

  try {
    statusMsg = await ctx.reply(
      '🔄 OSCARDEOB memulai analisis…\n' +
      '📄 Input: ' + safeName + '\n' +
      '🛡️ Uploaded code execution: OFF'
    );

    const tgFile = await ctx.api.getFile(doc.file_id);
    if (!tgFile.file_path) throw new Error('Telegram tidak memberikan file_path.');
    const url = `https://api.telegram.org/file/bot${TOKEN}/${tgFile.file_path}`;
    const response = await fetch(url);
    if (!response.ok) throw new Error(`Gagal mengunduh file dari Telegram: HTTP ${response.status}`);
    const bytes = Buffer.from(await response.arrayBuffer());
    if (bytes.length > MAX_MB * 1024 * 1024) throw new Error(`File melebihi batas ${MAX_MB} MB.`);
    fs.writeFileSync(inputPath, bytes);

    const source = fs.readFileSync(inputPath, 'utf8');
    const result = runDeobfuscation(source);
    fs.writeFileSync(outputPath, result.code, 'utf8');

    const phaseLines = result.report.map(p => `${p.status === 'OK' ? '✅' : '⚠️'} ${p.phase} · ${p.name}: ${p.status}`);
    const report = [
      'OSCARDEOB — ANALYSIS REPORT',
      `Job: ${job}`,
      `Input: ${safeName}`,
      `Input size: ${fmt(result.inputBytes)}`,
      `Output size: ${fmt(result.outputBytes)}`,
      `Duration: ${duration(result.durationMs)}`,
      '',
      ...phaseLines,
      '',
      'METRICS',
      `String literals decoded: ${result.metrics.stringsDecoded}`,
      `String-array lookups: ${result.metrics.arrayLookups}`,
      `Constant folds: ${result.metrics.folds}`,
      `Identifiers renamed: ${result.metrics.renamed}`,
      `Warnings: ${result.metrics.warnings.length}`,
      ...result.metrics.warnings.map(x => '- ' + x),
      '',
      'SAFETY: Static analysis only. Uploaded JavaScript was not executed.',
      'LIMITATION: Best-effort transformation; dynamic/custom decoders may remain.'
    ].join('\n');
    fs.writeFileSync(reportPath, report, 'utf8');

    const summary =
      '✅ OSCARDEOB — ANALISIS SELESAI\n\n' +
      `📥 Input: ${safeName}\n` +
      `📤 Output: index.deobf.js\n` +
      `📦 Ukuran: ${fmt(result.inputBytes)} → ${fmt(result.outputBytes)}\n` +
      `⏱️ Durasi: ${duration(result.durationMs)}\n` +
      `🔓 String decode: ${result.metrics.stringsDecoded}\n` +
      `🧩 Array lookup: ${result.metrics.arrayLookups}\n` +
      `🧮 Constant fold: ${result.metrics.folds}\n` +
      `🏷️ Rename identifier: ${result.metrics.renamed}\n\n` +
      phaseLines.join('\n') +
      '\n\n🛡️ Uploaded code execution: OFF\n📄 Detail tersedia di laporan.';
    await ctx.api.editMessageText(ctx.chat.id, statusMsg.message_id, summary);
    await ctx.replyWithDocument(new InputFile(outputPath, 'index.deobf.js'), {
      caption: '✅ Hasil deobfuscation (best-effort, static-only).'
    });
    await ctx.replyWithDocument(new InputFile(reportPath, 'oscardeob-report.txt'), {
      caption: '📊 Laporan lengkap tahapan dan metrik.'
    });
  } catch (err) {
    const msg = `❌ Gagal memproses file: ${String(err.message || err).slice(0, 700)}`;
    if (statusMsg) {
      try { await ctx.api.editMessageText(ctx.chat.id, statusMsg.message_id, msg); }
      catch (_) { await ctx.reply(msg); }
    } else await ctx.reply(msg);
  } finally {
    active.delete(ctx.from.id);
    fs.rmSync(tempDir, { recursive: true, force: true });
  }
});

bot.catch(err => console.error('Bot error:', err));
bot.start({
  onStart: info => console.log(`OSCARDEOB aktif sebagai @${info.username}`)
});
process.once('SIGINT', () => bot.stop());
process.once('SIGTERM', () => bot.stop());
