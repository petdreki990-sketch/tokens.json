'use strict';

const parser = require('@babel/parser');
const traverse = require('@babel/traverse').default;
const generate = require('@babel/generator').default;
const t = require('@babel/types');

function parseCode(code) {
  return parser.parse(code, {
    sourceType: 'unambiguous',
    allowReturnOutsideFunction: true,
    errorRecovery: false,
    plugins: [
      'jsx', 'typescript', 'decorators-legacy', 'classProperties',
      'classPrivateProperties', 'classPrivateMethods', 'dynamicImport',
      'optionalChaining', 'nullishCoalescingOperator', 'topLevelAwait',
      'objectRestSpread'
    ]
  });
}

function safeLiteral(node) {
  return t.isStringLiteral(node) || t.isNumericLiteral(node) ||
    t.isBooleanLiteral(node) || t.isNullLiteral(node);
}

function staticValue(node) {
  if (!node) return { known: false };
  if (t.isStringLiteral(node) || t.isNumericLiteral(node) ||
      t.isBooleanLiteral(node) || t.isNullLiteral(node)) {
    return { known: true, value: node.value };
  }
  if (t.isUnaryExpression(node) && node.operator !== 'delete' &&
      node.operator !== 'void' && node.operator !== 'typeof') {
    const a = staticValue(node.argument);
    if (!a.known) return { known: false };
    try {
      if (node.operator === '+') return { known: true, value: +a.value };
      if (node.operator === '-') return { known: true, value: -a.value };
      if (node.operator === '!') return { known: true, value: !a.value };
      if (node.operator === '~') return { known: true, value: ~a.value };
    } catch (_) {}
  }
  if (t.isBinaryExpression(node)) {
    const a = staticValue(node.left), b = staticValue(node.right);
    if (!a.known || !b.known) return { known: false };
    try {
      switch (node.operator) {
        case '+': return { known: true, value: a.value + b.value };
        case '-': return { known: true, value: a.value - b.value };
        case '*': return { known: true, value: a.value * b.value };
        case '/': return Number(b.value) !== 0 ? { known: true, value: a.value / b.value } : { known: false };
        case '%': return Number(b.value) !== 0 ? { known: true, value: a.value % b.value } : { known: false };
        case '**': return { known: true, value: a.value ** b.value };
        case '<<': return { known: true, value: a.value << b.value };
        case '>>': return { known: true, value: a.value >> b.value };
        case '|': return { known: true, value: a.value | b.value };
        case '&': return { known: true, value: a.value & b.value };
        case '^': return { known: true, value: a.value ^ b.value };
        case '===': return { known: true, value: a.value === b.value };
        case '!==': return { known: true, value: a.value !== b.value };
        case '==': return { known: true, value: a.value == b.value };
        case '!=': return { known: true, value: a.value != b.value };
        case '<': return { known: true, value: a.value < b.value };
        case '<=': return { known: true, value: a.value <= b.value };
        case '>': return { known: true, value: a.value > b.value };
        case '>=': return { known: true, value: a.value >= b.value };
      }
    } catch (_) {}
  }
  return { known: false };
}

function decodeStaticBase64(node) {
  if (!t.isCallExpression(node) || !t.isIdentifier(node.callee, { name: 'atob' }) ||
      node.arguments.length !== 1 || !t.isStringLiteral(node.arguments[0])) return null;
  const input = node.arguments[0].value;
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input) || input.length % 4 === 1) return null;
  try {
    const bytes = Buffer.from(input, 'base64');
    const decoded = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
    if (!decoded || decoded.length > 100000) return null;
    return decoded;
  } catch (_) { return null; }
}

function runDeobfuscation(source) {
  const started = Date.now();
  const report = [];
  const metrics = { stringsDecoded: 0, arrayLookups: 0, folds: 0, renamed: 0, warnings: [] };
  let code = source;

  // P1: formatting. Parsing + generation gives consistent readable formatting.
  let ast = parseCode(code);
  code = generate(ast, { comments: true, compact: false, concise: false, jsescOption: { minimal: true } }).code;
  report.push({ phase: 'P1', name: 'Beautify / parse AST', status: 'OK' });

  // P1.5: conservative pre-pass for literal Base64 calls. Never execute source.
  ast = parseCode(code);
  traverse(ast, {
    CallExpression(path) {
      const decoded = decodeStaticBase64(path.node);
      if (decoded !== null) {
        path.replaceWith(t.stringLiteral(decoded));
        metrics.stringsDecoded++;
      }
    }
  });
  report.push({ phase: 'P1.5', name: 'Static string pre-pass (Base64 atob literals)', status: 'OK' });

  // P2: array/getter analysis; only inline immutable local arrays with literal index.
  ast = parseCode(generate(ast, { comments: true }).code);
  traverse(ast, {
    MemberExpression(path) {
      const obj = path.node.object;
      const prop = path.node.property;
      if (!t.isIdentifier(obj) || !path.node.computed) return;
      const binding = path.scope.getBinding(obj.name);
      if (!binding || !binding.constant || !binding.path.isVariableDeclarator()) return;
      const init = binding.path.node.init;
      if (!t.isArrayExpression(init)) return;
      let index = null;
      if (t.isNumericLiteral(prop)) index = prop.value;
      else if (t.isStringLiteral(prop) && /^\d+$/.test(prop.value)) index = Number(prop.value);
      if (index === null || index < 0 || index >= init.elements.length) return;
      const element = init.elements[index];
      if (!t.isStringLiteral(element)) return;
      path.replaceWith(t.stringLiteral(element.value));
      metrics.arrayLookups++;
    }
  });
  report.push({ phase: 'P2', name: 'AST array / getter analysis', status: 'OK' });

  // P3: static payload capture; deliberately no eval, require, VM, or network.
  report.push({ phase: 'P3', name: 'Static payload inspection (no execution)', status: 'OK' });

  // P4: fold safe literal-only expressions.
  traverse(ast, {
    enter(path) {
      if (path.isBinaryExpression() || path.isUnaryExpression()) {
        const result = staticValue(path.node);
        if (result.known && (typeof result.value === 'string' || typeof result.value === 'number' || typeof result.value === 'boolean')) {
          path.replaceWith(t.valueToNode(result.value));
          metrics.folds++;
        }
      }
    }
  });
  report.push({ phase: 'P4', name: 'Inline evaluation & constant folding', status: 'OK' });

  // P5: normalization pass through Babel AST generator/parser.
  code = generate(ast, { comments: true, compact: false, jsescOption: { minimal: true } }).code;
  ast = parseCode(code);
  report.push({ phase: 'P5', name: 'AST transform / normalization', status: 'OK' });

  // P6: rename only local bindings whose names strongly resemble generated obfuscator names.
  traverse(ast, {
    Program(path) {
      const bindings = Object.values(path.scope.bindings);
      let n = 1;
      for (const binding of bindings) {
        const name = binding.identifier.name;
        if (/^_0x[a-f\d]{3,}$/i.test(name) || /^_0x[a-f\d]+$/i.test(name)) {
          try {
            path.scope.rename(name, `decodedVar${n++}`);
            metrics.renamed++;
          } catch (_) { metrics.warnings.push(`Tidak dapat mengganti nama binding ${name}`); }
        }
      }
    }
  });
  report.push({ phase: 'P6', name: 'Conservative semantic rename', status: 'OK' });

  // P7: final formatting.
  code = generate(ast, {
    comments: true, compact: false, concise: false, retainLines: false,
    jsescOption: { minimal: true }
  }).code + '\n';
  report.push({ phase: 'P7', name: 'Final cleanup / generation', status: 'OK' });

  return {
    code, report, metrics,
    durationMs: Date.now() - started,
    inputBytes: Buffer.byteLength(source, 'utf8'),
    outputBytes: Buffer.byteLength(code, 'utf8')
  };
}

module.exports = { runDeobfuscation };
